package com.zangdaru.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private Ui.Pal p;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ArrayList<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            need.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!CalSync.has(this)) {
            need.add("android.permission.READ_CALENDAR");
            need.add("android.permission.WRITE_CALENDAR");
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 1);
        new Thread(() -> CalSync.heal(this)).start();
        Alarms.scheduleAll(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rc, perms, res);
        new Thread(() -> CalSync.heal(this)).start();
        build();
    }

    private void build() {
        p = Ui.pal(this);
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad);
        sv.addView(col);

        // ---- header ----
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setBackground(Ui.box(this, p.primary, 24));
        head.setPadding(pad, pad, pad, pad);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        head.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 72)));
        LinearLayout tc = new LinearLayout(this);
        tc.setOrientation(LinearLayout.VERTICAL);
        tc.setPadding(pad, 0, pad, 0);
        tc.addView(Ui.text(this, "زنگ دارو", 30, Color.WHITE, true));
        tc.addView(Ui.text(this, "یادآور مصرف دارو و وقت پزشک", 16, Color.WHITE, false));
        head.addView(tc);
        col.addView(head, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        // ---- notifications warning ----
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.areNotificationsEnabled()) {
            LinearLayout warn = new LinearLayout(this);
            warn.setOrientation(LinearLayout.VERTICAL);
            warn.setBackground(Ui.box(this, 0xFFFFE0B2, 16));
            warn.setPadding(pad, pad, pad, pad);
            warn.addView(Ui.text(this, "⚠️ اعلان‌های برنامه خاموش است و زنگ دارو به‌درستی کار نمی‌کند.", 17, 0xFF5D4037, true));
            TextView fix = Ui.button(this, "روشن کردن اعلان‌ها", 0xFFFB8C00, Color.WHITE);
            fix.setOnClickListener(v -> openNotificationSettings());
            warn.addView(fix, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
            col.addView(warn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        }

        // ---- four steps, each with its own color and symbol ----
        col.addView(step("💊", "افزودن یادآوری دارو", "داروی جدید با عکس و ساعت‌های مصرف",
                0xFFD81B60, EditActivity.class), Ui.lp(this, Ui.MATCH, Ui.WRAP, 16));
        col.addView(step("🩺", "افزودن یادآور نوبت پزشک", "نام پزشک، روز و ساعت مراجعه",
                0xFFEF6C00, ApptEditActivity.class), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        col.addView(step("📅", "مشاهده تقویم نوبت و دارو", "تقویم شمسی سال با روزهای دارو و پزشک",
                0xFF1E88E5, CalendarActivity.class), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        col.addView(step("⚙️", "مشاهده تنظیمات برنامه", "رنگ برنامه، راهنما، درباره‌ی برنامه",
                0xFF2E7D32, SettingsActivity.class), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));

        // ---- next doctor visit ----
        long now = System.currentTimeMillis();
        Appt next = null;
        for (Appt a : Store.allAppts(this)) { if (a.millis() > now) { next = a; break; } }
        if (next != null) {
            LinearLayout nc = new LinearLayout(this);
            nc.setOrientation(LinearLayout.VERTICAL);
            nc.setBackground(Ui.box(this, 0xFFFFE0B2, 20));
            nc.setPadding(pad, pad, pad, pad);
            nc.addView(Ui.text(this, "🩺 وقت بعدی پزشک", 16, 0xFF5D4037, true));
            nc.addView(Ui.text(this, next.doctor, 22, 0xFF3E2723, true));
            nc.addView(Ui.text(this, Jalali.fmtFull(next.dateKey) + " - ساعت " + next.timeText(), 17, 0xFF3E2723, false));
            nc.setOnClickListener(v -> startActivity(new Intent(this, AppointmentsActivity.class)));
            col.addView(nc, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        }

        // ---- medicines ----
        col.addView(Ui.text(this, "💊 داروهای من", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 20));
        ArrayList<Med> meds = Store.all(this);
        if (meds.isEmpty()) {
            TextView empty = Ui.text(this, "هنوز دارویی اضافه نکرده‌اید.\nروی «افزودن یادآوری دارو» بزنید.", 18, p.text, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(pad, Ui.dp(this, 24), pad, Ui.dp(this, 24));
            col.addView(empty, Ui.lp(this, Ui.MATCH, Ui.WRAP, 4));
        }
        for (Med m : meds) col.addView(card(m), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));

        Ui.apply(this, sv);
    }

    /** One big colored step button: round white badge with a symbol, title, short hint, arrow. */
    private View step(String emoji, String title, String sub, int color, final Class<?> target) {
        int pad = Ui.dp(this, 14);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.box(this, color, 22));
        row.setPadding(pad, pad, pad, pad);
        row.setMinimumHeight(Ui.dp(this, 88));

        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.WHITE);
        TextView icon = Ui.text(this, emoji, 30, color, false);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(circle);
        row.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 62), Ui.dp(this, 62)));

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(pad, 0, pad, 0);
        tx.addView(Ui.text(this, title, 21, Color.WHITE, true));
        tx.addView(Ui.text(this, sub, 14, 0xFFFFFFFF, false));
        row.addView(tx, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));

        row.addView(Ui.text(this, "‹", 34, Color.WHITE, true));
        row.setOnClickListener(v -> startActivity(new Intent(this, target)));
        return row;
    }

    private View card(final Med m) {
        int pad = Ui.dp(this, 12);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.box(this, p.soft, 20));
        row.setPadding(pad, pad, pad, pad);

        int size = Ui.dp(this, 76);
        if (m.hasPhoto()) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(Ui.decodeFile(m.photo, 300));
            row.addView(iv, new LinearLayout.LayoutParams(size, size));
        } else {
            TextView pill = Ui.text(this, "💊", 36, p.text, false);
            pill.setGravity(Gravity.CENTER);
            pill.setBackground(Ui.box(this, Color.WHITE, 16));
            row.addView(pill, new LinearLayout.LayoutParams(size, size));
        }
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(pad, 0, pad, 0);
        info.addView(Ui.text(this, m.name, 22, p.text, true));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < m.times.size(); i++) {
            if (i > 0) sb.append(" ، ");
            sb.append(Jalali.fa(m.times.get(i)));
        }
        info.addView(Ui.text(this, "🕐 " + sb, 18, p.text, false));
        if (m.byDates()) info.addView(Ui.text(this, "📅 روزهای انتخابی از تقویم", 15, p.text, false));
        int left = m.daysLeft();
        String rest = left > 0 ? Jalali.fa(String.valueOf(left)) + " روز مانده" : "دوره‌ی مصرف تمام شد";
        info.addView(Ui.text(this, rest, 15, p.primary, true));
        row.addView(info, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        row.setOnClickListener(v -> {
            Intent i = new Intent(this, EditActivity.class);
            i.putExtra("id", m.id);
            startActivity(i);
        });
        return row;
    }

    private void openNotificationSettings() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()));
        }
        startActivity(i);
    }
}
