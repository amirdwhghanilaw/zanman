package com.zangdaru.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Full-screen screen shown when it is time to take a medicine: shows the saved photo. */
public class AlarmActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        final int medId = getIntent().getIntExtra("med", -1);
        final int idx = getIntent().getIntExtra("idx", 0);
        final int nid = getIntent().getIntExtra("nid", 0);
        final Med m = Store.get(this, medId);
        if (m == null) { Alarms.dismiss(this, nid); finish(); return; }

        Ui.Pal p = Ui.pal(this);
        int pad = Ui.dp(this, 16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(p.bg);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = Ui.text(this, "⏰ وقت مصرف دارو است", 28, p.primary, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));
        if (idx < m.times.size()) {
            TextView tm = Ui.text(this, Ui.fa(m.times.get(idx)), 22, p.text, false);
            tm.setGravity(Gravity.CENTER);
            root.addView(tm, Ui.lp(this, Ui.MATCH, Ui.WRAP, 2));
        }

        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER);
        box.setBackground(Ui.box(this, p.soft, 24));
        box.setPadding(pad, pad, pad, pad);
        Bitmap bmp = m.hasPhoto() ? Ui.decodeFile(m.photo, 1024) : null;
        if (bmp != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setImageBitmap(bmp);
            box.addView(iv, new LinearLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        } else {
            box.addView(Ui.text(this, "💊", 120, p.text, false));
        }
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f);
        bl.topMargin = Ui.dp(this, 12);
        root.addView(box, bl);

        TextView name = Ui.text(this, m.name, 32, p.text, true);
        name.setGravity(Gravity.CENTER);
        root.addView(name, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        if (!m.note.isEmpty()) {
            TextView note = Ui.text(this, m.note, 20, p.text, false);
            note.setGravity(Gravity.CENTER);
            root.addView(note, Ui.lp(this, Ui.MATCH, Ui.WRAP, 2));
        }

        TextView taken = Ui.button(this, "✅  مصرف کردم", 0xFF2E9E5B, Color.WHITE);
        taken.setTextSize(24);
        taken.setOnClickListener(v -> { Alarms.dismiss(this, nid); finish(); });
        root.addView(taken, Ui.lp(this, Ui.MATCH, Ui.dp(this, 70), 14));

        TextView snooze = Ui.button(this, "⏰  ۱۰ دقیقه بعد یادآوری کن", 0xFF2878C8, Color.WHITE);
        snooze.setOnClickListener(v -> { Alarms.snooze(this, medId, idx, nid); finish(); });
        root.addView(snooze, Ui.lp(this, Ui.MATCH, Ui.dp(this, 62), 10));

        Ui.apply(this, root);
    }
}
